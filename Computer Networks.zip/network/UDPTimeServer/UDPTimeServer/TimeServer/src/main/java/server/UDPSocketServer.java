package server;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.io.File;
import java.util.Random;

public class UDPSocketServer     {

    //Opcodes and packet size
    private static final byte OP_RRQ = 1;
    private static final byte OP_WRQ = 2;
    private static final byte OP_DATAPACKET = 3;
    private static final byte OP_ACK = 4;
    private static final byte OP_ERROR = 5;
    private byte MAX_RESEND = 5;
    public final static int PACKET_SIZE = 512;

    private DatagramSocket recieverSocket;
    private int defaultport = 2000;
    private byte[] dataBuffer = new byte[PACKET_SIZE];
    private int TIME_OUT = 1000; //1 second
    private DatagramSocket sendSocket;
    private byte currentBlockSeq = 1;
    private DatagramPacket ackDP = new DatagramPacket(new byte[4], 4);
    private DatagramPacket request;
    private FileInputStream filename = null;
    private int sendport;
    private InetAddress sendaddress;


    // Main Function
    public static void main(String[] args) throws Exception {
        UDPSocketServer tftpServer = new UDPSocketServer();
        tftpServer.run();
    }
    // carries out the connection and all of the operation.
    public void run() throws SocketException{
        try{
            recieverSocket = new DatagramSocket(defaultport,InetAddress.getLocalHost());
            System.out.println("TftpServer connect to port number " + recieverSocket.getLocalPort());

            while(true){
                byte[] buf = new byte[PACKET_SIZE];
                DatagramPacket p = new DatagramPacket(buf, PACKET_SIZE);
                System.out.println("waiting for client connection  ....");
                recieverSocket.receive(p);
                request = p;
                sendport = p.getPort();
                sendaddress = p.getAddress();


                byte pType = TypeOfRequest(request);
                if(pType == 1 || pType == 2){


                    String File_name = getfilename(p);
                    System.out.println("Requested file name:" + File_name );

                    File fil = new File(File_name);
                    if (!fil.exists()){
                      SendErrorPacket(File_name);
                      System.out.println("sent");
                    }
                    else {
                        sendfiles(File_name);
                        System.out.println(" exist");
                    }


                }

            }

        }
        catch(Exception e) {
            System.err.println("Exception: " + e);
        }
        recieverSocket.close();

    }
    // read the data from the file and adding to global variable databuffer
    private void sendfiles(String filename) throws Exception {
        Random rand = new Random();
        int number = rand.nextInt(10000);
        sendSocket = new DatagramSocket(number);
        File myObj = new File(filename);
        FileInputStream fileInput = new FileInputStream(myObj);
        System.out.println("file found");

        while(true){
            int rec = fileInput.read(dataBuffer);

            //the file size is a multiple of 512, send empty packet
            if (rec < 512 && rec > 0 ) {
                System.out.println("The last packet ["+rec+" bytes in size]:#"+currentBlockSeq);
                boolean successed = sendDataPacket(dataBuffer,rec);
                break;
            }


            //send a file data packet
            boolean successed = sendDataPacket(dataBuffer,rec);
            //tried five times
            if (!successed) {
                System.out.println("Tried five times, give up");
                break;
            }

            // the last packet (the file size if not a multiple of 512)

            currentBlockSeq++;
        }
        fileInput.close();
        sendSocket.close();

    }
    // send the data packet
    private  boolean sendDataPacket(byte[] databuffer,int length) throws Exception{
        int resendCount = 0;

        DatagramPacket dataPacket = setFileDataPacket(databuffer,length);
        //try five times
        while(resendCount < MAX_RESEND){
            try{
                // sendsocket.send(datapacket
                sendSocket.send(dataPacket);
                sendSocket.setSoTimeout(TIME_OUT);
                System.out.println("sent data block #"+ currentBlockSeq +", waiting for ack #" + currentBlockSeq);
                //ack arrives

                sendSocket.receive(ackDP);
                byte ackedBlockseq = extractACKNumber(ackDP);
                System.out.println("received ack #" + ackedBlockseq);
                if(ackedBlockseq != currentBlockSeq) {
                    //the acked block seq is not the seq of block sent
                    //ignore this ack and resend
                    resendCount++;
                    continue;
                }
                //this data packet has been acked, return True
                return true;

            }//end of try
            catch(SocketTimeoutException ste){
                resendCount++;
                System.out.println("timeout #" + resendCount );
            }
        }//end of while
        return false;
    }


    // Type of request is sent by client
    private byte TypeOfRequest(DatagramPacket packet) {
        byte [] arr = packet.getData();
        System.out.println(arr[1]);
        byte  oppcode = arr[1];
        return oppcode;
    }

    // Extract the Ack number
    private byte extractACKNumber(DatagramPacket packet){
        byte [] data = packet.getData();
        System.out.println(data[2]);
        return data[2];

    }
    // create error packet
    private byte [] CreateErrorPacket(final byte Opcode,String filename){
        String ErrorMessage = "File not exist";

        byte ZeroByte = 0;
        int ErrorPacketLength = 4 + ErrorMessage.length() + 1;
        byte[] ErrorByteArray = new byte[ErrorPacketLength];

        int position = 0;
        ErrorByteArray[position] = ZeroByte;
        position++;
        ErrorByteArray[position] = Opcode;
        position ++;
        for (int i = 0; i < ErrorMessage.length(); i++) {
            ErrorByteArray[position] = (byte) ErrorMessage.charAt(i);
            position++;
        }
        ErrorByteArray[position] = ZeroByte;
        return ErrorByteArray;
    }
    // send the error packet
    public void SendErrorPacket(String filename) throws IOException {
        Random rand = new Random();
        int number = rand.nextInt(10000);
        sendSocket = new DatagramSocket(number);
        byte [] ErrorPacket = CreateErrorPacket(OP_ERROR,filename);
        DatagramPacket Error = new DatagramPacket(ErrorPacket,ErrorPacket.length,sendaddress,sendport);
        sendSocket.send(Error);
        sendSocket.close();

    }
    // create the data packet
    private DatagramPacket setFileDataPacket(byte[] dataBuffer, int length){
        int dataByteLength = 2 + 2 + dataBuffer.length;

        ByteBuffer data = ByteBuffer.allocate(dataByteLength);
        data.put((byte)0);
        data.put(OP_DATAPACKET);
        data.put(currentBlockSeq);
        data.put(dataBuffer);

        DatagramPacket dataPacket = new DatagramPacket(data.array(), dataByteLength,sendaddress,sendport);
        return  dataPacket;

    }
    // create acknowledgement packet
    private  DatagramPacket ack(){
        byte[] ACK = { 0, OP_ACK, 0 };
        DatagramPacket ack = new DatagramPacket(ACK, ACK.length, sendaddress, sendport);
        return ack;

    }
    // file name is extracted
    private String getfilename(DatagramPacket p){
        byte[] requestBuffer = p.getData();
        int dataLength = p.getLength();
        String name= new String(requestBuffer,2,dataLength - 5 - 3).trim();
        return name;

    }




}