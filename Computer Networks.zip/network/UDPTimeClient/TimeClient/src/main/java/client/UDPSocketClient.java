package client;
import java.io.*;
import java.util.Scanner;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.*;

public class UDPSocketClient {

    private static final String SERVER_IP = "10.100.126.112";
    private static final int DEFAULT_PORT = 2000;

    // TFTP OP Code
    private static final byte OP_RRQ = 1;
    private static final byte OP_WRQ = 2;
    private static final byte OP_DATAPACKET = 3;
    private static final byte OP_ACK = 4;
    private static final byte OP_ERROR = 5;

    private final static int PACKET_SIZE = 512;

    private DatagramSocket datagramSocket = null;
    private InetAddress inetAddress = null;
    private byte[] requestByteArray;
    private byte[] bufferByteArray;
    private DatagramPacket outBoundDatagramPacket;
    private DatagramPacket inBoundDatagramPacket;
    private static final String fileName = "spor.txt";
    private ByteArrayOutputStream OutputStream;

    public static void main(String[] args) throws IOException {
        UDPSocketClient  tFTPClientNet = new UDPSocketClient ();
        System.out.println("Press 1: SendRRQ request press 2: SendWRQ request" );

        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter Your Command");
        int userName = Integer.parseInt(myObj.nextLine());

        if (userName == 1) {
            tFTPClientNet.createFile(fileName);
            tFTPClientNet.RequestSend(OP_RRQ, fileName);
        } else if (userName == 2) {
            tFTPClientNet.RequestSend(OP_WRQ, fileName);
        }
    }




    // create a packet for Read request and write request
    private void RequestSend(final byte opCode,String fileName) throws IOException {

        // STEP 1: Creating a connection
        inetAddress = InetAddress.getLocalHost();
        datagramSocket = new DatagramSocket();
        requestByteArray = createRequest(opCode, fileName, "octet");
        outBoundDatagramPacket = new DatagramPacket(requestByteArray,
                requestByteArray.length, inetAddress, DEFAULT_PORT);

        // STEP 2: sending request RRQ to TFTP server fo a file
        datagramSocket.send(outBoundDatagramPacket);

        // STEP 3: receive file from TFTP server
        ByteArrayOutputStream byteOutputOS = receiveFile();
        OutputStream = byteOutputOS;

        // STEP 4: write file to local disc
        writeFile(byteOutputOS, fileName);
    }

    // receiving the file data packet from server
    private ByteArrayOutputStream receiveFile() throws IOException {
        ByteArrayOutputStream byteOutOS = new ByteArrayOutputStream();
        int block = 1;
        do {
            System.out.println("TFTP Packet count: " + block);
            block++;
            bufferByteArray = new byte[PACKET_SIZE];
            inBoundDatagramPacket = new DatagramPacket(bufferByteArray,
                    bufferByteArray.length, inetAddress,
                    datagramSocket.getLocalPort());

            //STEP 2.1: receive packet from TFTP server
            datagramSocket.receive(inBoundDatagramPacket);

            // Getting the first 4 characters from the TFTP packet
            byte[] opCode = { bufferByteArray[0], bufferByteArray[1] };
            if (opCode[1] == OP_ERROR) {
                reportingError();


            }

            else if (opCode[1] == OP_DATAPACKET) {
                // Check for the TFTP packets block number
                byte[] blockNumber = { bufferByteArray[2], bufferByteArray[3] };

                DataOutputStream dos = new DataOutputStream(byteOutOS);
                dos.write(inBoundDatagramPacket.getData(), 4,
                        inBoundDatagramPacket.getLength() - 4);

                //STEP 2.2: send ACK to TFTP server for received packet
                sendAcknowledgment(blockNumber);
                System.out.println(new String(inBoundDatagramPacket.getData()));
            }

        } while (!LastPacket(inBoundDatagramPacket));


        return byteOutOS;
    }
    // send the block number to server
    private void sendAcknowledgment(byte[] blockNumber) {

        byte[] ACK = { 0, OP_ACK, blockNumber[0], blockNumber[1] };

        // TFTP Server communicates back on a new PORT
        // so get that PORT from in bound packet and
        // send acknowledgment to it
        DatagramPacket ack = new DatagramPacket(ACK, ACK.length, inetAddress,
                    inBoundDatagramPacket.getPort());
        try {
            datagramSocket.send(ack);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // print the type of error occurred
    private void reportingError() {
        String ErrorCode = new String(bufferByteArray,3,1);
        String ErrorText = new String(bufferByteArray, 4,
                inBoundDatagramPacket.getLength() - 4);

        System.out.println("The Error: " +"f"+ErrorCode +   " " + ErrorText);
    }
    // write a file
    private void writeFile(ByteArrayOutputStream baoStream, String fileName) {
        try {
            OutputStream outputStream = new FileOutputStream(fileName);
            baoStream.writeTo(outputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // check weather is the last packet
    private boolean LastPacket(DatagramPacket datagramPacket) {
        return datagramPacket.getLength() < 512;
    }


    // create a request packet
    private byte[] createRequest(final byte opCode, final String fileName,
                                 final String mode) {
        byte zeroByte = 0;
        int rrqByteLength = 2 + fileName.length() + 1 + mode.length() + 1;
        byte[] rrqByteArray = new byte[rrqByteLength];

        int position = 0;
        rrqByteArray[position] = zeroByte;
        position++;
        rrqByteArray[position] = opCode;
        position++;
        for (int i = 0; i < fileName.length(); i++) {
            rrqByteArray[position] = (byte) fileName.charAt(i);
            position++;
        }
        rrqByteArray[position] = zeroByte;
        position++;
        for (int j = 0; j < mode.length(); j++) {
            rrqByteArray[position] = (byte) mode.charAt(j);
            position++;
        }
        rrqByteArray[position] = zeroByte;
        return rrqByteArray;

    }
    //  Create a file in the project file
    public  void createFile(String fileName){

            try {

                BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
                bw.close();


            } catch (IOException e) {
                e.printStackTrace();
            }
        }





}